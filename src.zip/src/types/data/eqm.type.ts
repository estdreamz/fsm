export interface DataEqmTypeFind {
  id: number;
  name: string;
  status: number;
  edit: boolean
}