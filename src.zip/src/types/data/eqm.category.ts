export interface EqmCategoryFind {
  id: number;
  name: string;
  status: number;
  edit: boolean;
}