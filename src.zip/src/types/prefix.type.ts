export interface PrefixFind {
  id: number;
  name: string;
  short_name: string;
  edit: boolean
}

export interface PrefixItem {
  id: number;
  name: string;
  short_name: string;
}