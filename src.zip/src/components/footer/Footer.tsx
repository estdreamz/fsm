const Footer = () => {
    return (
        <div className="text-center my-3">
            Power by CODE inc.
        </div>
    );
};

export default Footer;