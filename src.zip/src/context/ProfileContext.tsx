import { createContext, useContext, useState, ReactNode } from "react";

interface MenuChildren {
  id: number;
  name: string;
  icon?: string | null;
  url: string;
  priority: number;
}

interface Menu {
  id: number;
  name: string;
  icon: string;
  url: string;
  priority: number;
  children: MenuChildren[];
}

interface Profile {
  id: number;
  code?: string | null;
  email: string;
  mobile?: string | null;
  prefix_id?: string | null;
  prefix_name?: string | null;
  first_name: string;
  last_name: string;
  full_name: string;
  photo: string | null;
  role_level: string;
  role_id: number;
  role_name: string;
  org_id?: string | null;
  org_name?: string | null;
  org_status?: string | null;
  status: number;
  last_login: string;
  menus: Menu[];
}

interface ProfileContextType {
  profile: Profile | null;
  setProfile: (profile: Profile | null) => void;
  clearProfile: () => void;
}

const ProfileContext = createContext<ProfileContextType | undefined>(undefined);

export const ProfileProvider = ({ children }: { children: ReactNode }) => {
  const [profile, setProfile] = useState<Profile | null>(null);

  const clearProfile = () => {
    setProfile(null);
  };

  return (
    <ProfileContext.Provider value={{ profile, setProfile, clearProfile }}>
      {children}
    </ProfileContext.Provider>
  );
};

export const useProfile = () => {
  const context = useContext(ProfileContext);
  if (!context) {
    throw new Error("useProfile must be used within a ProfileProvider");
  }
  return context;
};
